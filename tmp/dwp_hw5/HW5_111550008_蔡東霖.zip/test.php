<?php
    require_once "./game_controller.php";
    
    Hall::showEntryPoint();

?>