<?php
// 111550008 蔡東霖 第5次作業 12/6
// 111550008 Tony Tsai The Fifth Homework 12/6
    require_once "./game_controller.php";
    
    Hall::showEntryPoint();
?>